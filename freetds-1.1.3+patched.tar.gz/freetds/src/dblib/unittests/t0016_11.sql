create table #dblib0016 (id int not null, var uniqueidentifier null, c1 char(20) not null, v1 varchar(20) not null, c2 char(20) null, v2 varchar(20) null, b1 binary(20) null, vb1 varbinary(20) null, img image null, txt text null)
go
select * from #dblib0016 where 0=1
go
select * from #dblib0016 where 0=1
go
drop table #dblib0016
go
