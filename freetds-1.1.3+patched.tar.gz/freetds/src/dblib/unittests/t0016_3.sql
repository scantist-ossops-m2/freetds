create table #dblib0016 (f1 int not null, f2 char(20) not null, f3 binary(4) not null)
go
select * from #dblib0016 where 0=1
go
select * from #dblib0016 where 0=1
go
drop table #dblib0016
go

