select getdate() as 'begintime' waitfor delay '00:00:30' select getdate() as 'endtime'
go
select getdate() as 'begintime' waitfor delay '00:00:30' select getdate() as 'endtime'
go
