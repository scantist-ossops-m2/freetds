//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by setup.rc
//
#define IDD_LOGIN                       102
#define IDD_DSN                         106
#define IDC_PROTOCOL                    1003
#define IDC_ADDRESS                     1004
#define IDC_PORT                        1005
#define IDC_DATABASE                    1011
#define IDC_DSNNAME                     1015
#define IDC_HINT                        1017
#define IDC_LOGINSERVER                 1020
#define IDC_LOGINUID                    1021
#define IDC_LOGINPWD                    1022
#define IDC_LOGINDUMP                   1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
