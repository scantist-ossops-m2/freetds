create table #dblib0016 (id int not null, var uniqueidentifier null, c1 nvarchar(200))
go
select * from #dblib0016 where 0=1
go
select * from #dblib0016 where 0=1
go
drop table #dblib0016
go
