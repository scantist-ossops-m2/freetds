set arithabort on
select 1
set arithabort on
select 2
go
